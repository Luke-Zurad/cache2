#ifndef COUNT_VOWELS_H_INCLUDED
#define COUNT_VOWELS_H_INCLUDED

int count_vowels(const char *str);

#endif // COUNT_VOWELS_H_INCLUDED
